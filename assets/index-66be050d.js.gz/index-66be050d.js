import{s as e,R as i,_ as n,j as r,W as t,T as o,D as s}from"./index-4c3a1d27.js";import{e as _}from"./constants-d0472dad.js";const d=e.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
    z-index: 1;
    align-items: center;
    padding-bottom: 50px;
    background-color: ${({theme:e})=>e.card_light};
`,c=e.div`
    width: 100%;
    max-width: 1000px;
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
`,a=i.lazy((()=>n((()=>import("./ExperienceCards-864953bc.js")),["assets/ExperienceCards-864953bc.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css"]))),p=i.lazy((()=>n((()=>import("./index-8163236c.js")),["assets/index-8163236c.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-0e03b939.js"]))),x=i.lazy((()=>n((()=>import("./index-3e90347b.js")),["assets/index-3e90347b.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-0e03b939.js","assets/timelineContentClasses-3a9d1e0a.js","assets/constants-d0472dad.js"]))),l=i.lazy((()=>n((()=>import("./index-94581027.js")),["assets/index-94581027.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css"]))),m=i.lazy((()=>n((()=>import("./index-ed4d2367.js")),["assets/index-ed4d2367.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css"]))),E=i.lazy((()=>n((()=>import("./index-41a1c2ee.js")),["assets/index-41a1c2ee.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-0e03b939.js","assets/timelineContentClasses-3a9d1e0a.js"]))),h=i.lazy((()=>n((()=>import("./index-4adfda90.js")),["assets/index-4adfda90.js","assets/index-4c3a1d27.js","assets/index-29a84fde.css"]))),j=()=>r.jsx(d,{id:"experience",children:r.jsxs(t,{children:[r.jsx(o,{children:"Experience"}),r.jsx(s,{children:"Below are some of my experiences base on my resume."}),r.jsx(c,{children:r.jsx(p,{children:_.map(((e,i)=>r.jsxs(x,{children:[r.jsxs(l,{children:[r.jsx(h,{variant:"outlined",sx:{borderColor:"#00DFA2"}}),i!==_.length-1&&r.jsx(m,{sx:{background:"-webkit-linear-gradient(225deg, rgb(0, 223, 162) 0%, rgb(1, 106, 112) 100%)"}})]}),r.jsx(E,{sx:{py:"12px",px:2},children:r.jsx(a,{experience:e})})]},i)))})})]})});export{j as default};
