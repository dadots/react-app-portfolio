import{r as e,e as r}from"./index-5578ac6b.js";const t=e.createContext({});function s(e){return"alternate-reverse"===e?"positionAlternateReverse":`position${r(e)}`}export{t as T,s as c};
