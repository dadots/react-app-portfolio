import{s as e,R as i,_ as n,j as r,W as t,T as o,D as s}from"./index-2b42d1a1.js";import{e as _}from"./constants-7a112278.js";const d=e.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
    z-index: 1;
    align-items: center;
    padding-bottom: 50px;
    background-color: ${({theme:e})=>e.card_light};
`,c=e.div`
    width: 100%;
    max-width: 1000px;
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
`,a=i.lazy((()=>n((()=>import("./ExperienceCards-165b5577.js")),["assets/ExperienceCards-165b5577.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css"]))),p=i.lazy((()=>n((()=>import("./index-0e3475b4.js")),["assets/index-0e3475b4.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-68604592.js"]))),x=i.lazy((()=>n((()=>import("./index-0de000e6.js")),["assets/index-0de000e6.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-68604592.js","assets/timelineContentClasses-da1e0d7f.js","assets/constants-7a112278.js"]))),l=i.lazy((()=>n((()=>import("./index-10908ee3.js")),["assets/index-10908ee3.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css"]))),m=i.lazy((()=>n((()=>import("./index-dcb89cfd.js")),["assets/index-dcb89cfd.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css"]))),E=i.lazy((()=>n((()=>import("./index-49dfb05d.js")),["assets/index-49dfb05d.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-68604592.js","assets/timelineContentClasses-da1e0d7f.js"]))),h=i.lazy((()=>n((()=>import("./index-51e6e6cd.js")),["assets/index-51e6e6cd.js","assets/index-2b42d1a1.js","assets/index-29a84fde.css"]))),j=()=>r.jsx(d,{id:"experience",children:r.jsxs(t,{children:[r.jsx(o,{children:"Experience"}),r.jsx(s,{children:"Below are some of my experiences base on my resume."}),r.jsx(c,{children:r.jsx(p,{children:_.map(((e,i)=>r.jsxs(x,{children:[r.jsxs(l,{children:[r.jsx(h,{variant:"outlined",sx:{borderColor:"#00DFA2"}}),i!==_.length-1&&r.jsx(m,{sx:{background:"-webkit-linear-gradient(225deg, rgb(0, 223, 162) 0%, rgb(1, 106, 112) 100%)"}})]}),r.jsx(E,{sx:{py:"12px",px:2},children:r.jsx(a,{experience:e})})]},i)))})})]})});export{j as default};
