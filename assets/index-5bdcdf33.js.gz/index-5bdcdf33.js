import{s as e,R as i,_ as n,j as r,W as t,T as o,D as s}from"./index-c216ddd3.js";import{e as _}from"./constants-0b03edc5.js";const d=e.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
    z-index: 1;
    align-items: center;
    padding-bottom: 50px;
    background-color: ${({theme:e})=>e.card_light};
`,c=e.div`
    width: 100%;
    max-width: 1000px;
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
`,a=i.lazy((()=>n((()=>import("./ExperienceCards-28ae1187.js")),["assets/ExperienceCards-28ae1187.js","assets/index-c216ddd3.js","assets/index-29a84fde.css"]))),p=i.lazy((()=>n((()=>import("./index-d78f3afd.js")),["assets/index-d78f3afd.js","assets/index-c216ddd3.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-3c15fa1a.js"]))),x=i.lazy((()=>n((()=>import("./index-28f65bdb.js")),["assets/index-28f65bdb.js","assets/index-c216ddd3.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-3c15fa1a.js","assets/timelineContentClasses-6886c4e9.js","assets/constants-0b03edc5.js"]))),l=i.lazy((()=>n((()=>import("./index-121331bd.js")),["assets/index-121331bd.js","assets/index-c216ddd3.js","assets/index-29a84fde.css"]))),m=i.lazy((()=>n((()=>import("./index-10ba6187.js")),["assets/index-10ba6187.js","assets/index-c216ddd3.js","assets/index-29a84fde.css"]))),E=i.lazy((()=>n((()=>import("./index-038b1358.js")),["assets/index-038b1358.js","assets/index-c216ddd3.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-3c15fa1a.js","assets/timelineContentClasses-6886c4e9.js"]))),h=i.lazy((()=>n((()=>import("./index-39c88045.js")),["assets/index-39c88045.js","assets/index-c216ddd3.js","assets/index-29a84fde.css"]))),j=()=>r.jsx(d,{id:"experience",children:r.jsxs(t,{children:[r.jsx(o,{children:"Experience"}),r.jsx(s,{children:"Below are some of my experiences base on my resume."}),r.jsx(c,{children:r.jsx(p,{children:_.map(((e,i)=>r.jsxs(x,{children:[r.jsxs(l,{children:[r.jsx(h,{variant:"outlined",sx:{borderColor:"#00DFA2"}}),i!==_.length-1&&r.jsx(m,{sx:{background:"-webkit-linear-gradient(225deg, rgb(0, 223, 162) 0%, rgb(1, 106, 112) 100%)"}})]}),r.jsx(E,{sx:{py:"12px",px:2},children:r.jsx(a,{experience:e})})]},i)))})})]})});export{j as default};
