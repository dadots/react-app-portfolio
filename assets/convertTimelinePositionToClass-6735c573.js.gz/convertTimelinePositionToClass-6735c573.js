import{r as t,e as n}from"./index-1710d65c.js";const o=t.createContext({}),i=o;function s(e){return e==="alternate-reverse"?"positionAlternateReverse":`position${n(e)}`}export{i as T,s as c};
