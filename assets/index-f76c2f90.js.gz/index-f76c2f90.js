import{s as e,R as i,_ as n,j as r,W as t,T as o,D as s}from"./index-95ab8227.js";import{e as _}from"./constants-b28ab03d.js";const d=e.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;
    z-index: 1;
    align-items: center;
    padding-bottom: 50px;
    background-color: ${({theme:e})=>e.card_light};
`,c=e.div`
    width: 100%;
    max-width: 1000px;
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
`,a=i.lazy((()=>n((()=>import("./ExperienceCards-c95075a4.js")),["assets/ExperienceCards-c95075a4.js","assets/index-95ab8227.js","assets/index-29a84fde.css"]))),p=i.lazy((()=>n((()=>import("./index-3099357a.js")),["assets/index-3099357a.js","assets/index-95ab8227.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-34e73640.js"]))),x=i.lazy((()=>n((()=>import("./index-16db7836.js")),["assets/index-16db7836.js","assets/index-95ab8227.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-34e73640.js","assets/timelineContentClasses-21a94b6e.js","assets/constants-b28ab03d.js"]))),l=i.lazy((()=>n((()=>import("./index-23702b6a.js")),["assets/index-23702b6a.js","assets/index-95ab8227.js","assets/index-29a84fde.css"]))),m=i.lazy((()=>n((()=>import("./index-e1f4ce7d.js")),["assets/index-e1f4ce7d.js","assets/index-95ab8227.js","assets/index-29a84fde.css"]))),E=i.lazy((()=>n((()=>import("./index-5a7c8c10.js")),["assets/index-5a7c8c10.js","assets/index-95ab8227.js","assets/index-29a84fde.css","assets/convertTimelinePositionToClass-34e73640.js","assets/timelineContentClasses-21a94b6e.js"]))),h=i.lazy((()=>n((()=>import("./index-da343145.js")),["assets/index-da343145.js","assets/index-95ab8227.js","assets/index-29a84fde.css"]))),j=()=>r.jsx(d,{id:"experience",children:r.jsxs(t,{children:[r.jsx(o,{children:"Experience"}),r.jsx(s,{children:"Below are some of my experiences base on my resume."}),r.jsx(c,{children:r.jsx(p,{children:_.map(((e,i)=>r.jsxs(x,{children:[r.jsxs(l,{children:[r.jsx(h,{variant:"outlined",sx:{borderColor:"#00DFA2"}}),i!==_.length-1&&r.jsx(m,{sx:{background:"-webkit-linear-gradient(225deg, rgb(0, 223, 162) 0%, rgb(1, 106, 112) 100%)"}})]}),r.jsx(E,{sx:{py:"12px",px:2},children:r.jsx(a,{experience:e})})]},i)))})})]})});export{j as default};
