import{r as t,b as n}from"./index-8c984e2e.js";const o=t.createContext({}),i=o;function s(e){return e==="alternate-reverse"?"positionAlternateReverse":`position${n(e)}`}export{i as T,s as c};
